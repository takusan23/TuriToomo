function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

(function (f) {
  if ((typeof exports === "undefined" ? "undefined" : _typeof(exports)) === "object" && typeof module !== "undefined") {
    module.exports = f();
  } else if (typeof define === "function" && define.amd) {
    define([], f);
  } else {
    var g;

    if (typeof window !== "undefined") {
      g = window;
    } else if (typeof global !== "undefined") {
      g = global;
    } else if (typeof self !== "undefined") {
      g = self;
    } else {
      g = this;
    }

    g.aez_bundle_main = f();
  }
})(function () {
  var define, module, exports;
  return function () {
    function r(e, n, t) {
      function o(i, f) {
        if (!n[i]) {
          if (!e[i]) {
            var c = "function" == typeof require && require;
            if (!f && c) return c(i, !0);
            if (u) return u(i, !0);
            var a = new Error("Cannot find module '" + i + "'");
            throw a.code = "MODULE_NOT_FOUND", a;
          }

          var p = n[i] = {
            exports: {}
          };
          e[i][0].call(p.exports, function (r) {
            var n = e[i][1][r];
            return o(n || r);
          }, p, p.exports, r, e, n, t);
        }

        return n[i].exports;
      }

      for (var u = "function" == typeof require && require, i = 0; i < t.length; i++) {
        o(t[i]);
      }

      return o;
    }

    return r;
  }()({
    1: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /**
       * 文字列からルビをパースする。
       * このパーサは、akashic-labelのデフォルトルビ記法のためのパーサである。
       *
       * このパーサを使う場合、ラベルに与える文字列にJSONのオブジェクトを表す文字列を含むことができる。
       * 文字列中のオブジェクトはルビを表す要素として扱われる。
       * オブジェクトのメンバーには、ルビを表す `rt` と、本文を表す `rb` を含む必要がある。
       * これらのメンバー以外に、RubyOptions型が持つメンバーを含むことができる。
       *
       * 入力の例として、
       * 'これは{"rb":"本文","rt":"ルビ", "rubyFontSize": 2}です。'
       * という文字列が与えられた場合、このパーサは
       * ["これは", {rb:"本文", rt: "ルビ", rubyFontSize: 2}, "です。"]
       * という配列を返す。
       * また、 `{` や `}` は `\\` でエスケープする必要がある。
       * 例として、括弧は `\\{` 、 バックスラッシュは `\\` を用いて表現する。
       * 注意すべき点として、オブジェクトのプロパティ名はダブルクォートでくくられている必要がある。
       */

      function parse(text) {
        var pattern = /^((?:[^\\{]|\\+.)*?)({(?:[^\\}]|\\+.)*?})([\s\S]*)/; // ((?:[^\\{]|\\+.)*?) -> オブジェクトリテラルの直前まで
        // ({(?:[^\\}]|\\+.)*?}) -> 最前のオブジェクトリテラル
        // ([\s\S]*) -> オブジェクトリテラル以降の、改行を含む文字列

        var result = [];

        while (text.length > 0) {
          var parsedText = text.match(pattern);

          if (parsedText !== null) {
            var headStr = parsedText[1];
            var rubyStr = parsedText[2];
            text = parsedText[3];

            if (headStr.length > 0) {
              result.push(headStr.replace(/\\{/g, "{").replace(/\\}/g, "}"));
            }

            var parseResult = JSON.parse(rubyStr.replace(/\\/g, "\\\\"));

            if (parseResult.hasOwnProperty("rt") && parseResult.hasOwnProperty("rb")) {
              parseResult.rt = parseResult.rt.replace(/\\{/g, "{").replace(/\\}/g, "}");
              parseResult.rb = parseResult.rb.replace(/\\{/g, "{").replace(/\\}/g, "}");
              parseResult.text = rubyStr;
              result.push(parseResult);
            } else {
              throw g.ExceptionFactory.createTypeMismatchError("parse", "RubyFragment");
            }
          } else {
            result.push(text.replace(/\\{/g, "{").replace(/\\}/g, "}"));
            break;
          }
        }

        return result;
      }

      exports.parse = parse;
    }, {}],
    2: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /**
       * 行に含まれる文字列要素。
       */

      var StringDrawInfo =
      /** @class */
      function () {
        function StringDrawInfo(text, width, glyphs) {
          this.text = text;
          this.width = width;
          this.glyphs = glyphs;
        }

        return StringDrawInfo;
      }();

      exports.StringDrawInfo = StringDrawInfo;
      /**
       * 行に含まれるルビ要素。
       */

      var RubyFragmentDrawInfo =
      /** @class */
      function () {
        function RubyFragmentDrawInfo(fragment, width, rbWidth, rtWidth, glyphs, rubyGlyphs) {
          this.text = fragment.text;
          this.fragment = fragment;
          this.width = width;
          this.rbWidth = rbWidth;
          this.rtWidth = rtWidth;
          this.glyphs = glyphs;
          this.rubyGlyphs = rubyGlyphs;
        }

        return RubyFragmentDrawInfo;
      }();

      exports.RubyFragmentDrawInfo = RubyFragmentDrawInfo;
    }, {}],
    3: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      var rp = require("./RubyParser");

      var fr = require("./FragmentDrawInfo");

      var dr = require("./DefaultRubyParser");
      /**
       * 複数行のテキストを描画するエンティティ。
       * 文字列内の"\r\n"、"\n"、"\r"を区切りとして改行を行う。
       * また、自動改行が有効な場合はエンティティの幅に合わせて改行を行う。
       * 本クラスの利用にはg.Fontが必要となる。
       */


      var Label =
      /** @class */
      function (_super) {
        __extends(Label, _super);
        /**
         * 各種パラメータを指定して `Label` のインスタンスを生成する。
         * @param param このエンティティに対するパラメータ
         */


        function Label(param) {
          var _this = _super.call(this, param) || this;

          _this.text = param.text;
          _this.font = param.font;
          _this.fontSize = param.fontSize;
          _this._lineBreakWidth = param.width;
          _this.lineBreak = "lineBreak" in param ? param.lineBreak : true;
          _this.lineGap = param.lineGap || 0;
          _this.textAlign = "textAlign" in param ? param.textAlign : g.TextAlign.Left;
          _this.textColor = param.textColor;
          _this.trimMarginTop = "trimMarginTop" in param ? param.trimMarginTop : false;
          _this.widthAutoAdjust = "widthAutoAdjust" in param ? param.widthAutoAdjust : false;
          _this.rubyEnabled = "rubyEnabled" in param ? param.rubyEnabled : true;
          _this.fixLineGap = "fixLineGap" in param ? param.fixLineGap : false;
          _this.rubyParser = "rubyParser" in param ? param.rubyParser : dr.parse;
          _this.lineBreakRule = "lineBreakRule" in param ? param.lineBreakRule : undefined;

          if (!param.rubyOptions) {
            param.rubyOptions = {};
          }

          _this.rubyOptions = param.rubyOptions;
          _this.rubyOptions.rubyFontSize = "rubyFontSize" in param.rubyOptions ? param.rubyOptions.rubyFontSize : param.fontSize / 2;
          _this.rubyOptions.rubyFont = "rubyFont" in param.rubyOptions ? param.rubyOptions.rubyFont : _this.font;
          _this.rubyOptions.rubyGap = "rubyGap" in param.rubyOptions ? param.rubyOptions.rubyGap : 0;
          _this.rubyOptions.rubyAlign = "rubyAlign" in param.rubyOptions ? param.rubyOptions.rubyAlign : rp.RubyAlign.SpaceAround;
          _this._lines = [];
          _this._beforeText = undefined;
          _this._beforeTextAlign = undefined;
          _this._beforeFontSize = undefined;
          _this._beforeLineBreak = undefined;
          _this._beforeFont = undefined;
          _this._beforeWidth = undefined;
          _this._beforeRubyEnabled = undefined;
          _this._beforeFixLineGap = undefined;
          _this._beforeTrimMarginTop = undefined;
          _this._beforeWidthAutoAdjust = undefined;
          _this._beforeRubyOptions = {};

          _this._invalidateSelf();

          return _this;
        }
        /**
         * このエンティティの描画キャッシュ無効化をエンジンに通知する。
         * このメソッドを呼び出し後、描画キャッシュの再構築が行われ、各 `g.Renderer` に描画内容の変更が反映される。
         */


        Label.prototype.invalidate = function () {
          this._invalidateSelf();

          _super.prototype.invalidate.call(this);
        };

        Label.prototype.renderCache = function (renderer) {
          if (!this.rubyEnabled && this.fontSize === 0) return;
          renderer.save();
          var currentLineHeight = 0;

          for (var i = 0; i < this._lines.length; ++i) {
            if (this._lines[i].width > 0 && this._lines[i].height > 0) {
              renderer.drawImage(this._lines[i].surface, 0, 0, this._lines[i].width, this._lines[i].height, this._offsetX(this._lines[i].width), currentLineHeight);
            }

            currentLineHeight += this._lines[i].height + this.lineGap;
          }

          if (this.textColor) {
            renderer.setCompositeOperation(g.CompositeOperation.SourceAtop);
            renderer.fillRect(0, 0, this._lineBreakWidth, this.height, this.textColor);
          }

          renderer.restore();
        };
        /**
         * 利用している `g.Surface` を破棄した上で、このエンティティを破棄する。
         * 利用している `g.Font` の破棄は行わないため、 `g.Font` の破棄はコンテンツ製作者が明示的に行う必要がある。
         */


        Label.prototype.destroy = function () {
          this._destroyLines();

          _super.prototype.destroy.call(this);
        };
        /**
         * 禁則処理によって行幅が this.width を超える場合があるため、 `g.CacheableE` のメソッドをオーバーライドする
         */


        Label.prototype.calculateCacheSize = function () {
          // TODO: 最大値の候補に this.width を使用するのは textAlign が g.Center か g.Right の場合に描画に必要なキャッシュサイズを確保するためであり、
          // 最大行幅に対して this.width が大きい場合、余分なキャッシュ領域を確保することになる。
          // これは g.CacheableE にキャッシュ描画位置を調整する cacheOffsetX を導入することで解決される。
          var maxWidth = Math.ceil(this._lines.reduce(function (width, line) {
            return Math.max(width, line.width);
          }, this.width));
          return {
            width: maxWidth,
            height: this.height
          };
        };

        Object.defineProperty(Label.prototype, "lineCount", {
          /**
           * 描画内容の行数を返す
           */
          get: function get() {
            return this._lines.length;
          },
          enumerable: true,
          configurable: true
        });

        Label.prototype._offsetX = function (width) {
          switch (this.textAlign) {
            case g.TextAlign.Left:
              return 0;

            case g.TextAlign.Right:
              return this._lineBreakWidth - width;

            case g.TextAlign.Center:
              return (this._lineBreakWidth - width) / 2;

            default:
              return 0;
          }
        };

        Label.prototype._destroyLines = function () {
          for (var i = 0; i < this._lines.length; i++) {
            if (this._lines[i].surface && !this._lines[i].surface.destroyed()) {
              this._lines[i].surface.destroy();
            }
          }

          this._lines = undefined;
        };

        Label.prototype._invalidateSelf = function () {
          if (this.fontSize < 0) throw g.ExceptionFactory.createAssertionError("Label#_invalidateSelf: fontSize must not be negative.");
          if (this.lineGap < -1 * this.fontSize) throw g.ExceptionFactory.createAssertionError("Label#_invalidateSelf: lineGap must be greater than -1 * fontSize."); // this.width がユーザから変更された場合、this._lineBreakWidth は this.width に追従する。

          if (this._beforeWidth !== this.width) this._lineBreakWidth = this.width;

          if (this._beforeText !== this.text || this._beforeFontSize !== this.fontSize || this._beforeFont !== this.font || this._beforeLineBreak !== this.lineBreak || this._beforeWidth !== this.width && this._beforeLineBreak === true || this._beforeTextAlign !== this.textAlign || this._beforeRubyEnabled !== this.rubyEnabled || this._beforeFixLineGap !== this.fixLineGap || this._beforeTrimMarginTop !== this.trimMarginTop || this._beforeWidthAutoAdjust !== this.widthAutoAdjust || this._isDifferentRubyOptions(this._beforeRubyOptions, this.rubyOptions)) {
            this._updateLines();
          }

          if (this.widthAutoAdjust) {
            // this.widthAutoAdjust が真の場合、 this.width は描画幅に応じてトリミングされる。
            this.width = Math.ceil(this._lines.reduce(function (width, line) {
              return Math.max(width, line.width);
            }, 0));
          }

          var height = this.lineGap * (this._lines.length - 1);

          for (var i = 0; i < this._lines.length; i++) {
            height += this._lines[i].height;
          }

          this.height = height;
          this._beforeText = this.text;
          this._beforeTextAlign = this.textAlign;
          this._beforeFontSize = this.fontSize;
          this._beforeLineBreak = this.lineBreak;
          this._beforeFont = this.font;
          this._beforeWidth = this.width;
          this._beforeRubyEnabled = this.rubyEnabled;
          this._beforeFixLineGap = this.fixLineGap;
          this._beforeTrimMarginTop = this.trimMarginTop;
          this._beforeWidthAutoAdjust = this.widthAutoAdjust;
          this._beforeRubyOptions.rubyFontSize = this.rubyOptions.rubyFontSize;
          this._beforeRubyOptions.rubyFont = this.rubyOptions.rubyFont;
          this._beforeRubyOptions.rubyGap = this.rubyOptions.rubyGap;
          this._beforeRubyOptions.rubyAlign = this.rubyOptions.rubyAlign;
        };

        Label.prototype._updateLines = function () {
          // ユーザのパーサを適用した後にも揃えるが、渡す前に改行記号を replace して統一する
          var fragments = this.rubyEnabled ? this.rubyParser(this.text.replace(/\r\n|\n/g, "\r")) : [this.text]; // Fragment のうち文字列のものを一文字ずつに分解する

          fragments = rp.flatmap(fragments, function (f) {
            if (typeof f !== "string") return f; // サロゲートペア文字を正しく分割する

            return f.replace(/\r\n|\n/g, "\r").match(/[\uD800-\uDBFF][\uDC00-\uDFFF]|[^\uD800-\uDFFF]/g) || [];
          });

          var undrawnLineInfos = this._divideToLines(fragments);

          var lines = [];
          var hasNotChanged = this._beforeFontSize === this.fontSize && this._beforeFont === this.font && !this._isDifferentRubyOptions(this._beforeRubyOptions, this.rubyOptions);

          for (var i = 0; i < undrawnLineInfos.length; i++) {
            var undrawnLineInfo = undrawnLineInfos[i];
            var line = this._lines[i];

            if (hasNotChanged && line !== undefined && undrawnLineInfo.sourceText === line.sourceText && undrawnLineInfo.width === line.width && undrawnLineInfo.height === line.height) {
              lines.push(line);
            } else {
              if (line && line.surface && !line.surface.destroyed()) {
                line.surface.destroy();
              }

              this._drawLineInfoSurface(undrawnLineInfo);

              lines.push(undrawnLineInfo);
            }
          } // 行数が減った場合、使われない行のSurfaceをdestroyする。


          for (var i = lines.length; i < this._lines.length; i++) {
            var line = this._lines[i];

            if (line.surface && !line.surface.destroyed()) {
              line.surface.destroy();
            }
          }

          this._lines = lines;
        };

        Label.prototype._drawLineInfoSurface = function (lineInfo) {
          var lineDrawInfo = lineInfo.fragmentDrawInfoArray;

          var rhi = this._calcRubyHeightInfo(lineDrawInfo);

          var lineSurface = this.scene.game.resourceFactory.createSurface(Math.ceil(lineInfo.width), Math.ceil(lineInfo.height));
          var lineRenderer = lineSurface.renderer();
          lineRenderer.begin();
          lineRenderer.save();
          var rbOffsetY = rhi.hasRubyFragmentDrawInfo || this.fixLineGap ? this.rubyOptions.rubyGap + rhi.maxRubyGlyphHeightWithOffsetY : 0;
          var minMinusOffsetY = lineInfo.minMinusOffsetY;

          for (var i = 0; i < lineDrawInfo.length; i++) {
            var drawInfo = lineDrawInfo[i];

            if (drawInfo instanceof fr.RubyFragmentDrawInfo) {
              this._drawRubyFragmentDrawInfo(lineRenderer, drawInfo, rbOffsetY - minMinusOffsetY, -rhi.minRubyMinusOffsetY);
            } else if (drawInfo instanceof fr.StringDrawInfo) {
              this._drawStringGlyphs(lineRenderer, this.font, drawInfo.glyphs, this.fontSize, 0, rbOffsetY - minMinusOffsetY, 0);
            }

            lineRenderer.translate(drawInfo.width, 0);
          }

          lineRenderer.restore();
          lineRenderer.end();
          lineInfo.surface = lineSurface;
        }; // 文字列の等幅描画


        Label.prototype._drawStringGlyphs = function (renderer, font, glyphs, fontSize, offsetX, offsetY, margin) {
          if (margin === void 0) {
            margin = 0;
          }

          renderer.save();
          renderer.translate(offsetX, offsetY);

          for (var i = 0; i < glyphs.length; i++) {
            var glyph = glyphs[i];
            var glyphScale = fontSize / font.size;
            var glyphWidth = glyph.advanceWidth * glyphScale;

            if (!glyph.isSurfaceValid) {
              glyph = this._createGlyph(glyph.code, font);
              if (!glyph) continue;
            }

            renderer.save();
            renderer.transform([glyphScale, 0, 0, glyphScale, 0, 0]);

            if (glyph.width > 0 && glyph.height > 0) {
              renderer.drawImage(glyph.surface, glyph.x, glyph.y, glyph.width, glyph.height, glyph.offsetX, glyph.offsetY);
            }

            renderer.restore();
            renderer.translate(glyphWidth + margin, 0);
          }

          renderer.restore();
        }; // ルビベースとルビテキストの描画


        Label.prototype._drawRubyFragmentDrawInfo = function (renderer, rubyDrawInfo, rbOffsetY, rtOffsetY) {
          var f = rubyDrawInfo.fragment;
          var rubyFontSize = "rubyFontSize" in f ? f.rubyFontSize : this.rubyOptions.rubyFontSize;
          var rubyAlign = "rubyAlign" in f ? f.rubyAlign : this.rubyOptions.rubyAlign;
          var rubyFont = "rubyFont" in f ? f.rubyFont : this.rubyOptions.rubyFont;
          var isRtWideThanRb = rubyDrawInfo.rtWidth > rubyDrawInfo.rbWidth;
          var width = rubyDrawInfo.width;
          var rtWidth = rubyDrawInfo.rtWidth;
          var rbWidth = rubyDrawInfo.rbWidth;
          var rtStartPositionX;
          var rbStartPositionX;
          var rtUnitMargin;
          var rbUnitMargin;

          switch (rubyAlign) {
            case rp.RubyAlign.Center:
              rtUnitMargin = 0;
              rbUnitMargin = 0;
              rtStartPositionX = isRtWideThanRb ? 0 : (width - rtWidth) / 2;
              rbStartPositionX = isRtWideThanRb ? (width - rbWidth) / 2 : 0;
              break;

            case rp.RubyAlign.SpaceAround:
              rtUnitMargin = rubyDrawInfo.rubyGlyphs.length > 0 ? (width - rtWidth) / rubyDrawInfo.rubyGlyphs.length : 0;
              rbUnitMargin = 0;
              rtStartPositionX = isRtWideThanRb ? 0 : rtUnitMargin / 2;
              rbStartPositionX = isRtWideThanRb ? (width - rbWidth) / 2 : 0;
              break;

            default:
              throw g.ExceptionFactory.createAssertionError("Label#_drawRubyFragmentDrawInfo: unknown rubyAlign.");
          }

          this._drawStringGlyphs(renderer, this.font, rubyDrawInfo.glyphs, this.fontSize, rbStartPositionX, rbOffsetY, rbUnitMargin);

          this._drawStringGlyphs(renderer, rubyFont, rubyDrawInfo.rubyGlyphs, rubyFontSize, rtStartPositionX, rtOffsetY, rtUnitMargin);
        };

        Label.prototype._calcRubyHeightInfo = function (drawInfoArray) {
          var maxRubyFontSize = this.rubyOptions.rubyFontSize;
          var maxRubyGlyphHeightWithOffsetY = 0;
          var maxRubyGap = this.rubyOptions.rubyGap;
          var hasRubyFragmentDrawInfo = false;
          var maxRealDrawHeight = 0;
          var realOffsetY;

          for (var i = 0; i < drawInfoArray.length; i++) {
            var ri = drawInfoArray[i];

            if (ri instanceof fr.RubyFragmentDrawInfo) {
              var f = ri.fragment;

              if (f.rubyFontSize > maxRubyFontSize) {
                maxRubyFontSize = f.rubyFontSize;
              }

              if (f.rubyGap > maxRubyGap) {
                maxRubyGap = f.rubyGap;
              }

              var rubyGlyphScale = (f.rubyFontSize ? f.rubyFontSize : this.rubyOptions.rubyFontSize) / (f.rubyFont ? f.rubyFont.size : this.rubyOptions.rubyFont.size);
              var currentMaxRubyGlyphHeightWithOffsetY = Math.max.apply(Math, ri.rubyGlyphs.map(function (glyph) {
                return glyph.offsetY > 0 ? glyph.height + glyph.offsetY : glyph.height;
              }));
              var currentMinRubyOffsetY = Math.min.apply(Math, ri.rubyGlyphs.map(function (glyph) {
                return glyph.offsetY > 0 ? glyph.offsetY : 0;
              }));

              if (maxRubyGlyphHeightWithOffsetY < currentMaxRubyGlyphHeightWithOffsetY * rubyGlyphScale) {
                maxRubyGlyphHeightWithOffsetY = currentMaxRubyGlyphHeightWithOffsetY * rubyGlyphScale;
              }

              var rubyFont = f.rubyFont ? f.rubyFont : this.rubyOptions.rubyFont;

              var currentRubyStandardOffsetY = this._calcStandardOffsetY(rubyFont);

              var currentFragmentRealDrawHeight = (currentMaxRubyGlyphHeightWithOffsetY - Math.min(currentMinRubyOffsetY, currentRubyStandardOffsetY)) * rubyGlyphScale;

              if (maxRealDrawHeight < currentFragmentRealDrawHeight) {
                maxRealDrawHeight = currentFragmentRealDrawHeight; // その行で描画されるルビのうち、もっとも実描画高さが高い文字が持つoffsetYを求める

                realOffsetY = Math.min(currentMinRubyOffsetY, currentRubyStandardOffsetY) * rubyGlyphScale;
              }

              hasRubyFragmentDrawInfo = true;
            }
          } // ルビが無い行でもfixLineGapが真の場合ルビの高さを使う


          if (maxRubyGlyphHeightWithOffsetY === 0) {
            maxRubyGlyphHeightWithOffsetY = this.rubyOptions.rubyFontSize;
          }

          var minRubyMinusOffsetY = this.trimMarginTop ? realOffsetY : 0;
          return {
            maxRubyFontSize: maxRubyFontSize,
            maxRubyGlyphHeightWithOffsetY: maxRubyGlyphHeightWithOffsetY,
            minRubyMinusOffsetY: minRubyMinusOffsetY,
            maxRubyGap: maxRubyGap,
            hasRubyFragmentDrawInfo: hasRubyFragmentDrawInfo
          };
        };

        Label.prototype._divideToLines = function (fragmentArray) {
          var state = {
            resultLines: [],
            currentStringDrawInfo: new fr.StringDrawInfo("", 0, []),
            currentLineInfo: {
              sourceText: "",
              fragmentDrawInfoArray: [],
              width: 0,
              height: 0,
              minMinusOffsetY: 0,
              surface: undefined
            },
            reservedLineBreakPosition: null
          };

          for (var i = 0; i < fragmentArray.length; i++) {
            this._addFragmentToState(state, fragmentArray, i);
          }

          this._flushCurrentStringDrawInfo(state);

          this._feedLine(state); // 行末ではないが、状態をflushするため改行処理を呼ぶ


          return state.resultLines;
        };

        Label.prototype._addFragmentToState = function (state, fragments, index) {
          var fragment = fragments[index];

          if (state.reservedLineBreakPosition !== null) {
            state.reservedLineBreakPosition--;
          }

          if (state.reservedLineBreakPosition === 0) {
            this._flushCurrentStringDrawInfo(state);

            this._feedLine(state);

            state.reservedLineBreakPosition = null;
          }

          if (typeof fragment === "string" && fragment === "\r") {
            /*
            // 行末に改行記号が来た場合、禁則処理によって改行すべきかは判断を保留し、一旦禁則処理による改行はしないことにする
            if (this._needFixLineBreakByRule(state)) {
                this._applyLineBreakRule(index, state);
            }
            */
            this._flushCurrentStringDrawInfo(state);

            this._feedLine(state);
          } else if (typeof fragment === "string") {
            var code = g.Util.charCodeAt(fragment, 0);
            if (!code) return;

            var glyph = this._createGlyph(code, this.font);

            if (!glyph) return;
            var glyphScale = this.fontSize / this.font.size;
            var glyphWidth = glyph.advanceWidth * glyphScale;

            if (this._needBreakLine(state, glyphWidth)) {
              this._breakLine(state, fragments, index);
            }

            state.currentStringDrawInfo.width += glyphWidth;
            state.currentStringDrawInfo.glyphs.push(glyph);
            state.currentStringDrawInfo.text += fragment;
          } else {
            var ri = this._createRubyFragmentDrawInfo(fragment);

            if (ri.width <= 0) return;

            this._flushCurrentStringDrawInfo(state);

            if (this._needBreakLine(state, ri.width)) {
              this._breakLine(state, fragments, index);
            }

            state.currentLineInfo.width += ri.width;
            state.currentLineInfo.fragmentDrawInfoArray.push(ri);
            state.currentLineInfo.sourceText += fragment.text;
          }
        };

        Label.prototype._createStringGlyph = function (text, font) {
          var glyphs = [];

          for (var i = 0; i < text.length; i++) {
            var code = g.Util.charCodeAt(text, i);
            if (!code) continue;

            var glyph = this._createGlyph(code, font);

            if (!glyph) continue;
            glyphs.push(glyph);
          }

          return glyphs;
        };

        Label.prototype._createGlyph = function (code, font) {
          var glyph = font.glyphForCharacter(code);

          if (!glyph) {
            var str = code & 0xFFFF0000 ? String.fromCharCode((code & 0xFFFF0000) >>> 16, code & 0xFFFF) : String.fromCharCode(code);
            this.game().logger.warn("Label#_invalidateSelf(): failed to get a glyph for '" + str + "' " + "(BitmapFont might not have the glyph or DynamicFont might create a glyph larger than its atlas).");
          }

          return glyph;
        };

        Label.prototype._createRubyFragmentDrawInfo = function (fragment) {
          var glyphs = this._createStringGlyph(fragment.rb, this.font);

          var rubyGlyphs = this._createStringGlyph(fragment.rt, this.rubyOptions.rubyFont);

          var rubyFont = "rubyFont" in fragment ? fragment.rubyFont : this.rubyOptions.rubyFont;
          var rubyFontSize = "rubyFontSize" in fragment ? fragment.rubyFontSize : this.rubyOptions.rubyFontSize;
          var glyphScale = this.fontSize / this.font.size;
          var rubyGlyphScale = rubyFontSize / rubyFont.size;
          var rbWidth = glyphs.length > 0 ? glyphs.map(function (glyph) {
            return glyph.advanceWidth;
          }).reduce(function (pre, cu) {
            return pre + cu;
          }) * glyphScale : 0;
          var rtWidth = rubyGlyphs.length > 0 ? rubyGlyphs.map(function (glyph) {
            return glyph.advanceWidth;
          }).reduce(function (pre, cu) {
            return pre + cu;
          }) * rubyGlyphScale : 0;
          var width = rbWidth > rtWidth ? rbWidth : rtWidth;
          return new fr.RubyFragmentDrawInfo(fragment, width, rbWidth, rtWidth, glyphs, rubyGlyphs);
        };

        Label.prototype._flushCurrentStringDrawInfo = function (state) {
          if (state.currentStringDrawInfo.width > 0) {
            state.currentLineInfo.fragmentDrawInfoArray.push(state.currentStringDrawInfo);
            state.currentLineInfo.width += state.currentStringDrawInfo.width;
            state.currentLineInfo.sourceText += state.currentStringDrawInfo.text;
          }

          state.currentStringDrawInfo = new fr.StringDrawInfo("", 0, []);
        };

        Label.prototype._feedLine = function (state) {
          var glyphScale = this.fontSize / this.font.size;
          var minOffsetY = Infinity;
          var minMinusOffsetY = 0;
          var maxGlyphHeightWithOffsetY = 0;
          state.currentLineInfo.fragmentDrawInfoArray.forEach(function (fragmentDrawInfo) {
            fragmentDrawInfo.glyphs.forEach(function (glyph) {
              if (minMinusOffsetY > glyph.offsetY) {
                minMinusOffsetY = glyph.offsetY;
              } // offsetYの一番小さな値を探す


              if (minOffsetY > glyph.offsetY) minOffsetY = glyph.offsetY;
              var heightWithOffsetY = glyph.offsetY > 0 ? glyph.height + glyph.offsetY : glyph.height;

              if (maxGlyphHeightWithOffsetY < heightWithOffsetY) {
                maxGlyphHeightWithOffsetY = heightWithOffsetY;
              }
            });
          });
          minMinusOffsetY = minMinusOffsetY * glyphScale;
          maxGlyphHeightWithOffsetY = state.currentLineInfo.fragmentDrawInfoArray.length > 0 ? maxGlyphHeightWithOffsetY * glyphScale - minMinusOffsetY : this.fontSize;
          maxGlyphHeightWithOffsetY = Math.ceil(maxGlyphHeightWithOffsetY);

          var rhi = this._calcRubyHeightInfo(state.currentLineInfo.fragmentDrawInfoArray);

          state.currentLineInfo.height = rhi.hasRubyFragmentDrawInfo || this.fixLineGap ? maxGlyphHeightWithOffsetY + rhi.maxRubyGlyphHeightWithOffsetY + rhi.maxRubyGap : maxGlyphHeightWithOffsetY;
          state.currentLineInfo.minMinusOffsetY = minMinusOffsetY;

          if (this.trimMarginTop) {
            var minOffsetYInRange = Math.min(minOffsetY, this._calcStandardOffsetY(this.font)) * glyphScale;
            state.currentLineInfo.height -= minOffsetYInRange;
            state.currentLineInfo.minMinusOffsetY += minOffsetYInRange;
          }

          state.resultLines.push(state.currentLineInfo);
          state.currentLineInfo = {
            sourceText: "",
            fragmentDrawInfoArray: [],
            width: 0,
            height: 0,
            minMinusOffsetY: 0,
            surface: undefined
          };
        };

        Label.prototype._needBreakLine = function (state, width) {
          return this.lineBreak && width > 0 && state.reservedLineBreakPosition === null && state.currentLineInfo.width + state.currentStringDrawInfo.width + width > this._lineBreakWidth && state.currentLineInfo.width + state.currentStringDrawInfo.width > 0; // 行頭文字の場合は改行しない
        };

        Label.prototype._isDifferentRubyOptions = function (ro0, ro1) {
          return ro0.rubyFontSize !== ro1.rubyFontSize || ro0.rubyFont !== ro1.rubyFont || ro0.rubyGap !== ro1.rubyGap || ro0.rubyAlign !== ro1.rubyAlign;
        };

        Label.prototype._calcStandardOffsetY = function (font) {
          // 標準的な高さを持つグリフとして `M` を利用するが明確な根拠は無い
          var text = "M";
          var glyphM = font.glyphForCharacter(text.charCodeAt(0));
          return glyphM.offsetY;
        };
        /** stateのcurrent系プロパティを禁則処理的に正しい構造に再構築する */


        Label.prototype._breakLine = function (state, fragments, index) {
          if (!this.lineBreakRule) {
            this._flushCurrentStringDrawInfo(state);

            this._feedLine(state);

            return;
          }

          var correctLineBreakPosition = this.lineBreakRule(fragments, index); // 外部ルールが期待する改行位置

          var diff = correctLineBreakPosition - index;

          if (diff === 0) {
            this._flushCurrentStringDrawInfo(state);

            this._feedLine(state);
          } else if (diff > 0) {
            // 先送り改行
            state.reservedLineBreakPosition = diff;
          } else {
            // 巻き戻し改行
            this._flushCurrentStringDrawInfo(state);

            var droppedFragmentDrawInfoArray = []; // currentLineInfoのfragmentDrawInfoArrayを巻き戻す

            while (diff < 0) {
              var fragmentDrawInfoArray = state.currentLineInfo.fragmentDrawInfoArray;
              var lastDrawInfo = fragmentDrawInfoArray[fragmentDrawInfoArray.length - 1];

              if (lastDrawInfo instanceof fr.RubyFragmentDrawInfo) {
                diff++;
                droppedFragmentDrawInfoArray.push(lastDrawInfo);
                fragmentDrawInfoArray.pop();
              } else {
                if (-diff >= lastDrawInfo.text.length) {
                  diff += lastDrawInfo.text.length;
                  droppedFragmentDrawInfoArray.push(lastDrawInfo);
                  fragmentDrawInfoArray.pop();
                } else {
                  var droppedGlyphs = lastDrawInfo.glyphs.splice(diff);
                  var glyphScale = this.fontSize / this.font.size;
                  var droppedDrawInfoWidth = droppedGlyphs.reduce(function (acc, glyph) {
                    return glyph.advanceWidth * glyphScale + acc;
                  }, 0);
                  lastDrawInfo.width -= droppedDrawInfoWidth;
                  var droppedDrawInfoText = lastDrawInfo.text.substring(lastDrawInfo.text.length + diff);
                  lastDrawInfo.text = lastDrawInfo.text.substring(0, lastDrawInfo.text.length + diff);
                  droppedFragmentDrawInfoArray.push(new fr.StringDrawInfo(droppedDrawInfoText, droppedDrawInfoWidth, droppedGlyphs));
                  diff = 0;
                }
              }
            } // currentLineInfoのその他を更新する


            var droppedWidth = 0;
            var droppedSourceText = "";
            droppedFragmentDrawInfoArray.forEach(function (fragment) {
              droppedWidth += fragment.width;
              droppedSourceText += fragment.text;
            });
            state.currentLineInfo.width -= droppedWidth;
            var sourceText = state.currentLineInfo.sourceText;
            state.currentLineInfo.sourceText = sourceText.substr(0, sourceText.length - droppedSourceText.length);

            this._feedLine(state);

            state.currentLineInfo.fragmentDrawInfoArray = droppedFragmentDrawInfoArray;
            state.currentLineInfo.width = droppedWidth;
            state.currentLineInfo.sourceText = droppedSourceText;
          }
        };

        return Label;
      }(g.CacheableE);

      module.exports = Label;
    }, {
      "./DefaultRubyParser": 1,
      "./FragmentDrawInfo": 2,
      "./RubyParser": 4
    }],
    4: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      var RubyAlign;

      (function (RubyAlign) {
        /**
         * rtの字間は固定で中央に揃える。
         */
        RubyAlign[RubyAlign["Center"] = 0] = "Center";
        /**
         * rb幅に合わせてrtの字間を揃える。
         */

        RubyAlign[RubyAlign["SpaceAround"] = 1] = "SpaceAround";
      })(RubyAlign = exports.RubyAlign || (exports.RubyAlign = {}));

      function flatmap(arr, func) {
        return Array.prototype.concat.apply([], arr.map(func));
      }

      exports.flatmap = flatmap;
    }, {}],
    5: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Label = require("./Label");
      exports.FragmentDrawInfo = require("./FragmentDrawInfo");
      exports.RubyParser = require("./RubyParser");
      exports.RubyAlign = exports.RubyParser.RubyAlign; // tslintが誤動作するので一時的に無効化する

      /* tslint:disable: no-unused-variable */

      var DRP = require("./DefaultRubyParser");

      exports.defaultRubyParser = DRP.parse;
      /* tslint:enable: no-unused-variable */
    }, {
      "./DefaultRubyParser": 1,
      "./FragmentDrawInfo": 2,
      "./Label": 3,
      "./RubyParser": 4
    }],
    6: [function (require, module, exports) {
      "use strict";

      var main_1 = require("./main");

      module.exports = function (originalParam) {
        var param = {};
        Object.keys(originalParam).forEach(function (key) {
          param[key] = originalParam[key];
        }); // セッションパラメーター

        param.sessionParameter = {}; // コンテンツが動作している環境がRPGアツマール上かどうか

        param.isAtsumaru = typeof window !== "undefined" && typeof window.RPGAtsumaru !== "undefined"; // 乱数生成器

        param.random = g.game.random;
        var limitTickToWait = 3; // セッションパラメーターが来るまでに待つtick数

        var scene = new g.Scene({
          game: g.game
        }); // セッションパラメーターを受け取ってゲームを開始します

        scene.message.add(function (msg) {
          if (msg.data && msg.data.type === "start" && msg.data.parameters) {
            param.sessionParameter = msg.data.parameters; // sessionParameterフィールドを追加

            if (msg.data.parameters.randomSeed != null) {
              param.random = new g.XorshiftRandomGenerator(msg.data.parameters.randomSeed);
            }

            g.game.popScene();
            main_1.main(param);
          }
        });
        scene.loaded.add(function () {
          var currentTickCount = 0;
          scene.update.add(function () {
            currentTickCount++; // 待ち時間を超えた場合はゲームを開始します

            if (currentTickCount > limitTickToWait) {
              g.game.popScene();
              main_1.main(param);
            }
          });
        });
        g.game.pushScene(scene);
      };
    }, {
      "./main": 7
    }],
    7: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      }); // 複数行表示に対応したやつ

      var al = require("@akashic-extension/akashic-label");

      function main(param) {
        var scene = new g.Scene({
          game: g.game,
          // このシーンで利用するアセットのIDを列挙し、シーンに通知します
          // tslint:disable-next-line: max-line-length
          assetIds: ["toomo", "nami", "nami_2", "nami_3", "hari", "hari_hanten", "karaoke", "bakkure_1", "doutei_toomo", "inu", "n_kou", "karaoke_2", "tuusinbo", "korean", "launch", "taoru", "GET", "GET_Short"]
        });
        var time = 60; // 制限時間

        if (param.sessionParameter.totalTimeLimit) {
          time = param.sessionParameter.totalTimeLimit; // セッションパラメータで制限時間が指定されたらその値を使用します
        } // 市場コンテンツのランキングモードでは、g.game.vars.gameState.score の値をスコアとして扱います


        g.game.vars.gameState = {
          score: 0
        };
        /** @param fishLevel 一度に釣れる量。 */

        var fishLevel = 2;
        /** @param nowFishCount 釣れたかず */

        var nowFishCount = 0;
        /** @param turibariList 釣り針の画像の配列 */

        var turibariList = [];
        /** @param fishList 生成した魚の配列 */

        var fishList = [];
        /** @param turibariXposList 釣り針の横の位置の配列 */

        var turibariXposList = [];
        /** @param turibariXposList 釣り針の縦の位置の配列 */

        var turibariYposList = [];
        /**
         * この関数はタイトル用のSceneを生成します。
         * @returns 生成したSceneです。
         */

        var createTitleScene = function createTitleScene() {
          var titlescene = new g.Scene({
            game: g.game,
            // このシーンで利用するアセットのIDを列挙し、シーンに通知します
            assetIds: ["title"]
          }); // 読み込んだら

          titlescene.loaded.add(function () {
            // タイトル画像を召喚します
            var titleImage = new g.Sprite({
              scene: titlescene,
              src: titlescene.assets["title"]
            });
            titlescene.append(titleImage);
          });
          return titlescene;
        }; // タイトル表示


        var titleScene = createTitleScene();
        titleScene.loaded.add(function () {
          // 5秒経過すればゲーム開始。
          titleScene.setTimeout(function () {
            // ゲームロードできた
            scene.loaded.add(function () {
              // 多分放送画面が暗いと文字が見えないので水色をバックに
              var blueBack = new g.FilledRect({
                scene: scene,
                cssColor: "lightskyblue",
                width: g.game.width,
                height: g.game.height
              });
              scene.append(blueBack); // プレイヤーを生成します

              var player = new g.Sprite({
                scene: scene,
                src: scene.assets["toomo"],
                width: scene.assets["toomo"].width,
                height: scene.assets["toomo"].height,
                x: 50,
                y: 50
              });
              scene.append(player); // 波の生成
              // 長くなったので関数へ

              createWave(scene); // フォントの生成

              var font = new g.DynamicFont({
                game: g.game,
                fontFamily: g.FontFamily.SansSerif,
                size: 40
              }); // スコア表示用のラベル

              var scoreLabel = new g.Label({
                scene: scene,
                text: "点数: 0",
                font: font,
                fontSize: font.size / 2,
                textColor: "black",
                x: g.game.width - 200
              });
              scene.append(scoreLabel); // 残り時間表示用ラベル

              var timeLabel = new g.Label({
                scene: scene,
                text: "TIME: 0",
                font: font,
                fontSize: font.size / 2,
                textColor: "black",
                x: 10
              });
              scene.append(timeLabel); // 釣った魚

              var fishLabel = new al.Label({
                scene: scene,
                text: "",
                fontSize: 15,
                font: font,
                width: 200,
                x: scoreLabel.x,
                y: scoreLabel.y + 20
              });
              scene.append(fishLabel); // 釣り糸

              var ito = new g.FilledRect({
                scene: scene,
                cssColor: "black",
                width: 5,
                height: 220,
                x: player.x + 100,
                y: player.y + 20
              });
              scene.append(ito);
              /**
               *  釣り針を増やす（足す）関数 。生成した画像は勝手に配列に入れておきますね。
               */

              var createHari = function createHari() {
                // 高さ。
                var yPos = ito.height + (50 - turibariList.length * 20); // 針の方向。

                var assetName = "hari";

                if (turibariList.length % 2 === 0) {
                  assetName = "hari";
                } else {
                  assetName = "hari_hanten";
                } // 横の位置。


                var xPos = ito.x;

                if (turibariList.length % 2 === 1) {
                  xPos = ito.x - 30; // 画像の幅だけ引いてる。
                }

                var hari_ = new g.Sprite({
                  scene: scene,
                  src: scene.assets[assetName],
                  x: xPos,
                  y: yPos
                });
                scene.append(hari_);
                turibariList.push(hari_);
                turibariXposList.push(xPos);
              }; // まず２個


              createHari();
              createHari(); // 押したとき
              // ここでは釣り糸を垂らして回収するまでをやってる。

              /** @param isFishing クリック連打対策用変数。釣り上げ動作以外で使ってない */

              var isFishing = false;
              /** @param isMoveTop 釣り上げ動作中はtrue */

              var isMoveTop = false;
              scene.pointDownCapture.add(function () {
                // クリック連打対策
                if (!isFishing) {
                  isFishing = true;
                  isMoveTop = false;
                  ito.update.removeAll(); // 釣り上げる

                  ito.update.add(function () {
                    isMoveTop = true;

                    if (100 <= ito.height) {
                      ito.height -= 10; // 釣り針上げる

                      turibariList.forEach(function (hari) {
                        hari.y -= 10;
                        hari.modified();
                        hari.invalidate();
                      }); // 魚を釣る。こっちに持ってきた。ずれるので

                      fishList.forEach(function (fish) {
                        if (fish.tag.isFished) {
                          // 釣り上げる～
                          fish.y += -10;
                          fish.modified(); // 縦の位置もずらす
                          // ずらさないとあとから釣れた魚の位置がおかしくなるため

                          turibariYposList.splice(0);
                          turibariList.forEach(function (hari) {
                            turibariYposList.push(hari.y - 10);
                          });
                        }
                      });
                    }

                    ito.modified();
                  }); // 海に戻す

                  scene.setTimeout(function () {
                    isMoveTop = false;
                    fishList.forEach(function (fish) {
                      if (fish.tag.isFished) {
                        fish.tag.isEnd = true;
                      }
                    });
                    ito.update.removeAll();
                    ito.update.add(function () {
                      if (g.game.height >= ito.height + 100) {
                        ito.height += 10;
                        turibariList.forEach(function (hari) {
                          hari.y += 10;
                          hari.modified();
                          hari.invalidate();
                        });
                      }

                      ito.modified();
                    });
                    isFishing = false; // 釣った魚も消す

                    scene.setTimeout(function () {
                      fishLabel.text = "";
                      fishLabel.invalidate();
                    }, 500); // いっぱいまで釣ったら釣れる数を増やす (釣れる数3で同時に3匹釣ったら→釣れる数を1足す)
                    // ただし5個まで。

                    if (nowFishCount === fishLevel && fishLevel < 5) {
                      fishLevel++; // 釣り針を足す

                      createHari();
                    } // 釣った数を戻す


                    nowFishCount = 0;
                  }, 1000);
                }
              }); // 押したとき。釣ります！

              scene.pointDownCapture.add(function () {
                // 配列全消し。高さの値を入れ直す
                turibariYposList.splice(0);
                turibariList.forEach(function (hari) {
                  turibariYposList.push(hari.y);
                });
                scene.update.add(function () {
                  fishList.forEach(function (fish) {
                    turibariList.forEach(function (hari) {
                      // まだ釣り上げていない場合
                      // 魚のtagにつけるオブジェクトに釣り上げたかどうがの値がfalseで
                      // それと引き上げたときのみ動くように
                      // それと同時に釣り上げる限界数より今釣ってる数のほうが小さい場合に
                      if (fish.tag.isFished === false && isMoveTop && nowFishCount < fishLevel) {
                        // 当たり判定。
                        if (g.Collision.intersectAreas(fish, hari)) {
                          // 釣り上げた判定に使う。
                          fish.tag.isFished = true;
                          var data_1 = fish.tag; // 魚の動きを消す

                          fish.update.removeAll(); // 釣れた数を増やす。のちに釣り針を増やすのに比較で使う。

                          fish.tag.fishCount = nowFishCount; // 初期の縦の位置設定
                          // console.log(turibariYposList[(fish.tag as FishTag).fishCount])

                          fish.y = turibariYposList[fish.tag.fishCount]; // 音を鳴らしてみた
                          // そーす：https://www.youtube.com/watch?v=wWqhBQVLB5I

                          scene.assets["GET_Short"].play();
                          nowFishCount++;
                          fish.modified();
                          fish.update.add(function () {
                            // 釣れた魚の位置合わせ
                            // これで針と魚が重なるようになる。
                            fish.x = turibariXposList[fish.tag.fishCount];

                            if (fish.tag.fishCount % 2 === 1) {
                              fish.x = turibariXposList[fish.tag.fishCount] - fish.width / 2;
                            } // なんとなく角度をつけてみる


                            if (fish.tag.fishCount % 2 === 0) {
                              fish.angle = 20;
                            } else {
                              fish.angle = 340;
                            } // 更新


                            fish.modified();

                            if (data_1.isEnd !== undefined) {
                              // 釣り上げた。魚削除など
                              if (data_1.point >= 0) {
                                // 正の数の場合は＋が省略されるので分岐
                                fishLabel.text += data_1.name + " +" + data_1.point + "\n";
                              } else {
                                fishLabel.text += data_1.name + " " + data_1.point + "\n";
                              }

                              fishLabel.invalidate();
                              fish.update.removeAll();
                              fish.destroy(); // 加点＋スコア表示
                              // ただし0より小さくならないように

                              if (g.game.vars.gameState.score + data_1.point >= 0) {
                                g.game.vars.gameState.score += data_1.point;
                                scoreLabel.text = "\u70B9\u6570: " + g.game.vars.gameState.score;
                                scoreLabel.invalidate();
                              }
                            }
                          });
                        }
                      }
                    });
                  });
                });
              });
              /** 乱数生成機。長いので短くするだけで中身はAkashic Engineのものを利用している。JSの物を使うとタイムシフトでの動作がおかしくなるためだって */

              var random = function random(min, max) {
                return g.game.random.get(min, max);
              };
              /** @param fishTemplate 流す魚の種類。 */


              var fishObjList;
              var karaokeObj = {
                asset: "karaoke",
                point: 200,
                name: "バックレカラオケ"
              };
              var tuusinboObj = {
                asset: "tuusinbo",
                name: "通信簿",
                point: 100
              };
              var inuObj = {
                asset: "inu",
                name: "レモン",
                point: 200
              };
              var dtObj = {
                asset: "doutei_toomo",
                name: "DT",
                point: 500
              };
              var ayaseObj = {
                asset: "n_kou",
                name: "スクーリング",
                point: -100
              };
              var koreanObj = {
                asset: "korean",
                name: "韓国",
                point: 200
              };
              var launchObj = {
                asset: "launch",
                name: "昼食",
                point: 200
              };
              var katsudonObj = {
                asset: "taoru",
                name: "カツドン",
                point: 200
              }; // 令和2020年

              var reiwa = {
                asset: undefined,
                text: "令和2020年",
                name: "令和2020年",
                point: 2020,
                speed: -30
              };
              /** @param fishTemplate 流す魚の種類。 */

              fishObjList = [karaokeObj, tuusinboObj, inuObj, dtObj, ayaseObj, koreanObj, launchObj, katsudonObj]; // 定期実行。setIntervalもAkashicEngineで用意されてる方を使う。これもニコ生のTSを考慮しているらしい。

              scene.setInterval(function () {
                // ランダムで魚を生成する。
                scene.setTimeout(function () {
                  // Array.length は配列の大きさ。でも0からではなく1なので-1しないといけない。
                  var randomNum = random(0, fishObjList.length - 1);
                  var fishObj = fishObjList[randomNum];
                  createFish(fishObj);
                }, random(100, 500)); // 残り40秒で増やす

                if (time <= 40) {
                  // ランダムで魚を生成する。
                  scene.setTimeout(function () {
                    var randomNum = random(0, fishObjList.length - 1);
                    var fishObj = fishObjList[randomNum];
                    createFish(fishObj);
                  }, random(100, 500));
                }
              }, 500);
              /**
               * 魚を作成する関数。
               * 制限時間を過ぎた場合、戻り値はnullになります。
               */

              var createFish = function createFish(data) {
                // 制限時間
                if (time <= 0) {
                  return null;
                }

                var karaoke; // 魚生成 or 文字生成（例：令和2020年）

                if (typeof data.asset !== "undefined") {
                  // 魚
                  karaoke = new g.Sprite({
                    scene: scene,
                    src: scene.assets[data.asset],
                    width: scene.assets[data.asset].width,
                    height: scene.assets[data.asset].height,
                    x: g.game.width,
                    y: g.game.random.get(150, g.game.height - scene.assets[data.asset].height)
                  });
                } else {
                  // 文字
                  karaoke = new g.Label({
                    scene: scene,
                    font: font,
                    text: data.text,
                    fontSize: 20,
                    x: g.game.width,
                    y: g.game.random.get(150, g.game.height - 20)
                  });
                } // 追加


                scene.append(karaoke); // 適当に流す

                karaoke.update.add(function () {
                  var _a;

                  karaoke.x += (_a = data.speed, _a !== null && _a !== void 0 ? _a : -10);
                  karaoke.modified();
                });
                fishList.push(karaoke); // 魚の情報を

                var tag = {
                  isFished: false,
                  point: data.point,
                  name: data.name,
                  isText: typeof data.asset !== "undefined"
                }; // 入れる

                karaoke.tag = tag;
              }; // 残り20秒で令和2020出す？


              scene.setTimeout(function () {
                // 流す魚の種類の配列に追加
                fishObjList.push(reiwa);
              }, 1000 * (time - 20)); // 制限時間から20引けば

              var updateHandler = function updateHandler() {
                if (time <= 0) {
                  // RPGアツマール環境であればランキングを表示します
                  if (param.isAtsumaru) {
                    var boardId_1 = 1;
                    window.RPGAtsumaru.experimental.scoreboards.setRecord(boardId_1, g.game.vars.gameState.score).then(function () {
                      window.RPGAtsumaru.experimental.scoreboards.display(boardId_1);
                    });
                  }

                  scene.update.remove(updateHandler); // カウントダウンを止めるためにこのイベントハンドラを削除します
                } // カウントダウン処理


                time -= 1 / g.game.fps;
                timeLabel.text = "残り時間: " + Math.ceil(time) + "秒";
                timeLabel.invalidate();
              };

              scene.update.add(updateHandler); // ここまでゲーム内容を記述します
            });
            g.game.pushScene(scene);
          }, 5000);
        });
        g.game.pushScene(titleScene);
      }

      exports.main = main;

      var createWave = function createWave(scene) {
        // 画像を切り替えて波っぽく
        var waveType = 0;
        var wave;
        wave = new g.Sprite({
          scene: scene,
          src: scene.assets["nami"],
          y: 100
        });
        waveType++;
        scene.append(wave);
        setInterval(function () {
          var waveSrc = "nami";

          switch (waveType) {
            case 0:
              waveSrc = "nami";
              break;

            case 1:
              waveSrc = "nami_2";
              break;

            case 2:
              waveSrc = "nami_3";
              break;
          }

          scene.remove(wave);
          wave = new g.Sprite({
            scene: scene,
            src: scene.assets[waveSrc],
            y: 100
          });
          scene.append(wave);
          waveType++;

          if (waveType > 3) {
            waveType = 0;
          }
        }, 1000 * 2);
      };
    }, {
      "@akashic-extension/akashic-label": 5
    }]
  }, {}, [6])(6);
});